# electron-express
This is a light weight integration of the express framework, with an electron application.
