module.exports = function() {

	app.get('/', function(req, res) {

		res.render('pages/home');
	});
}
